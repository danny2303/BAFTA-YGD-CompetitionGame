function love.conf(t)

	t.title = "CompetitionGame"
	t.window.width = 1200
	t.window.height = 750
	
end
